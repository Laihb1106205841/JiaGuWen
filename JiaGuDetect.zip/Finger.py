import cv2
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity


def extract_features(image):
    # 灰度化
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 计算梯度
    gradient_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    gradient_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)

    # 计算梯度幅值和方向
    magnitude = np.sqrt(gradient_x ** 2 + gradient_y ** 2)
    direction = np.arctan2(gradient_y, gradient_x)

    # 对方向场进行平滑处理
    smoothed_direction = cv2.GaussianBlur(direction, (0, 0), 2)

    # 提取特征，可以根据具体需求选择不同的特征
    features = smoothed_direction.flatten()

    return features


def fingerprint_matching(given_image, database_images):
    # 提取给定图片的特征
    given_image_features = extract_features(given_image)

    # 提取数据库中的特征
    database_features = [extract_features(img) for img in database_images]

    # 计算余弦相似度
    similarity_scores = cosine_similarity([given_image_features], database_features)

    return similarity_scores[0]


# 示例用法
# 读取给定图片
given_image = cv2.imread('given_fingerprint.jpg')

# 读取数据库中的多个指纹图片
database_images = [cv2.imread('database_fingerprint1.jpg'), cv2.imread('database_fingerprint2.jpg')]

# 进行指纹匹配
similarity_score = fingerprint_matching(given_image, database_images)

# 打印相似性得分
print("相似性得分:", similarity_score)
