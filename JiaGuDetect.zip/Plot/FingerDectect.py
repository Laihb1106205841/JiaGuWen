# # -*- coding: utf-8 -*-
# import numpy as np
# import cv2
# #==========读取、显示指纹图像============
# fp= cv2.imread("D:\Python\JiaGuWen\JiaGuDetect\Preprocessing\skeletonWithKernelM.png")
# cv2.imshow("fingerprint",fp)
# #==========SIFT==================
# sift = cv2.SIFT_create()  #SIFT专利已经到期，可以正常使用。要安装贡献包：opencv-contrib-python
# kp, des = sift.detectAndCompute(fp, None)
# #==========绘制关键点==================
# cv2.drawKeypoints(fp,kp,fp)
# #==========显示关键点信息、描述符==================
# print("关键点个数：",len(kp))              #显示kp的长度
# print("前五个关键点：",kp[:5])             #显示前5条数据
# print("第一个关键点的坐标：",kp[0].pt)
# print("第一个关键点的区域：",kp[0].size)
# print("第一个关键点的角度：",kp[0].angle)
# print("第一个关键点的响应：",kp[0].response)
# print("第一个关键点的层数：",kp[0].octave)
# print("第一个关键点的类id：",kp[0].class_id)
# print("描述符形状:",np.shape(des))         #显示des的形状
# print("第一个描述符:",des[0])              #显示des[0]的值
# #==========可视化关键点==================
# cv2.imshow("points",fp)
# cv2.waitKey()
# cv2.destroyAllWindows()

import cv2
import numpy as np

def extract_minutiae(img_path):
    # 读取图像
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

    # 使用Gabor滤波增强图像的ridge特征
    gabor_kernel = cv2.getGaborKernel((10, 10), 10.0, np.pi/4, 11.0, 0.6, 0, ktype=cv2.CV_32F)
    img_filtered = cv2.filter2D(img, cv2.CV_8UC3, gabor_kernel)

    # 二值化处理
    # _, img_binary = cv2.threshold(img_filtered, 50, 255, cv2.THRESH_BINARY)

    # 查找图像中的轮廓
    contours, _ = cv2.findContours(img_filtered, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    minutiae_list = []

    # 遍历轮廓，提取Minutiae特征点
    for contour in contours:
        for point in contour:
            x, y = point[0]
            if img[y, x] == 255:  # 仅处理二值化后的白色区域
                minutiae_list.append((x, y))

    return minutiae_list

# 指定图像路径
image_path = "/skeleton.png"

# 提取特征点
minutiae_points = extract_minutiae(image_path)

# 在原始图像上绘制特征点
img_color = cv2.imread(image_path)
for point in minutiae_points:
    cv2.circle(img_color, point, 4, (0, 0, 255), -1)

print(minutiae_points)

# 显示结果图像
cv2.imshow("Minutiae Points", img_color)
cv2.waitKey(0)
cv2.destroyAllWindows()
