import cv2
import numpy as np
import matplotlib.pyplot as plt


def endpoints_of_skeleton(center_line_img):
    '''
    center_line_img: 骨架线
    返回骨架的端点坐标
    '''
    W, H = center_line_img.shape
    img = center_line_img
    endpoints = []
    x, y = np.where(img > 0)

    for i, j in zip(x, y):
        if i - 1 < 0 or j - 1 < 0 \
                or i + 1 >= W or j + 1 >= H:
            continue
            # 条件A 该点的四领域内仅有一个点与之连接
        c_a = (img[i - 1, j] + img[i + 1, j] + img[i, j - 1] + img[i, j + 1]) == 255

        # 条件B 该点的对角领域内仅有一个点与之连接
        c_b = (img[i - 1, j - 1] + img[i - 1, j + 1] + img[i + 1, j - 1] + img[i + 1, j + 1]) == 255

        # 该点的八领域内仅有一个点
        if (img[i - 1:i + 2, j - 1:j + 2] == 255).sum() <= 2:
            endpoints.append([i, j])

        # 同时满足两个条件AB，且设置八种其余的端点坐标情况，如：
        '''
           ##0  0##         
           0#0  0#0   ...
           000  000
        '''

        if c_a and c_b:
            if (img[i - 1, j - 1:j + 2] == 255).sum() == 2 \
                    or (img[i + 1, j - 1:j + 2] == 255).sum() == 2 \
                    or (img[i - 1:i + 2, j - 1] == 255).sum() == 2 \
                    or (img[i - 1:i + 2, j + 1] == 255).sum() == 2:
                endpoints.append([i, j])

    return endpoints


if __name__ == '__main__':
    img = cv2.imread('D:\Python\JiaGuWen\JiaGuDetect\Preprocessing\skeletonWithKernelM.png', 0)

    # 阈值 二值化图像
    img[img > 100] = 255
    img[img <= 100] = 0
    endpoints = endpoints_of_skeleton(img)

    x = [x[0] for x in endpoints]
    y = [y[1] for y in endpoints]

    plt.imshow(img)
    plt.scatter(y, x, s=50, c='w', marker="*")
    plt.show()