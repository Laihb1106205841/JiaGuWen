import cv2
from skimage import morphology
import numpy as np
import requests


# Download the picture
def download(file_path, picture_url):
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/63.0.3239.132 "
                      "Safari/537.36 QIHU 360SE",
    }
    r = requests.get(picture_url, headers=headers)
    with open(file_path, 'wb') as f:
        f.write(r.content)


# Step1 load
url = 'https://qxk.bnu.edu.cn/pic_server//images/chinesedatabase/tp-zb-cropper-img/'

jpg = '91f241991f164cacb7450afe7f2fee82.jpg!70!10000000'

url = url+jpg
filePath = 'D:/Python/JiaGuWen/JiaGuWen/JiaGuWen.png'
download(filePath, url)

img = cv2.imread(filePath)
cv2.imshow('img', img)
cv2.waitKey()

# Step2 Grey Picture
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Step3 Turn Picture into binary part
_, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)

cv2.imshow('img', binary)
cv2.waitKey()


#  ###################### Optional Choice: Lower the noise of image#####################
#  Convolution Kernel
kernel = np.ones((3, 3), np.float32) / 10
# Convolution, make the tunnel the same as original picture
dst = cv2.filter2D(img, -1, kernel)


#  read your image that is in low noise
img = cv2.imread('1.png', 0)  # read image
# _,binary = cv2.threshold(img, 200, 255, cv2.THRESH_BINARY_INV)  # thresh binary inv
cv2.imwrite("binary.png", binary)  # save your binary thresh png

cv2.imshow('img', binary)
cv2.waitKey()
#  #####################################################################################

# Step4 take out skeleton
binary[binary == 255] = 1
skeleton0 = morphology.skeletonize(binary)
skeleton = skeleton0.astype(np.uint8) * 255
cv2.imshow('img', skeleton)
cv2.waitKey()
# save your skeleton picture
cv2.imwrite("skeletonWithKernelM028_2.png", skeleton)
