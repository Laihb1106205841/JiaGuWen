import cv2
import numpy as np

# 读取图像
image = cv2.imread('D:\Python\JiaGuWen\JiaGuDetect\Preprocessing\skeletonWithKernelM.png', cv2.IMREAD_GRAYSCALE)

# 二值化图像
_, binary_image = cv2.threshold(image, 128, 255, cv2.THRESH_BINARY)

# Canny边缘检测
edges = cv2.Canny(binary_image, 5, 255)

# 查找轮廓
contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# 检查是否至少有一个轮廓
if contours:
    # 提取轮廓上的点
    points = np.vstack(contours[0]).squeeze()

    # 检查点的数量是否足够
    if len(points) > 1:
        # 计算距离矩阵
        distances = np.linalg.norm(points[:, np.newaxis, :] - points, axis=2)

        # 生成邻接矩阵
        threshold = 1  # 距离阈值
        adjacency_matrix = (distances < threshold).astype(int)

        # 在识别到的点上绘制星星
        for point in points:
            cv2.drawMarker(image, tuple(point), color=(0, 255, 0),
                           markerType=cv2.MARKER_STAR, markerSize=3,
                           thickness=2)

        # 展示带有星星的图像
        cv2.imshow('Image with Stars', image)
        cv2.waitKey(0)
        cv2.destroyAllWindows()

        print("Adjacency Matrix:")
        print(adjacency_matrix)
        print(len(adjacency_matrix))
    else:
        print("Not enough points in the contour.")
else:
    print("No contours found.")
