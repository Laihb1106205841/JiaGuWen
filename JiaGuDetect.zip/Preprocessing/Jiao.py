import cv2
import numpy as np

# 读取图像
img = cv2.imread("D:\Python\JiaGuWen\JiaGuDetect\Preprocessing\skeletonWithKernelM.png")
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Harris角点检测参数
block_size = 7
ksize = 7
k = 0.10

# 使用Harris角点检测
corners = cv2.cornerHarris(gray, block_size, ksize, k)

# 选择角点
threshold = 0.01 * corners.max()
corner_img = np.copy(img)
corner_img[corners > threshold] = [0, 0, 255]  # 将角点标记为红色

print(len(corners))

# 统计大于阈值的元素个数
corner_points = (corners > threshold).sum()

print(f"角点数量: {corner_points}")

# 显示结果图像
# cv2.imshow("Original Image", img)
cv2.imshow("Detected Corners", corner_img)
cv2.waitKey(0)
cv2.destroyAllWindows()
