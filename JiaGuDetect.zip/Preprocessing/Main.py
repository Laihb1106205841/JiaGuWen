import requests
from bs4 import BeautifulSoup
import os
from urllib.parse import urljoin

WebUrl = "https://qxk.bnu.edu.cn/pic_server//images/chinesedatabase/tp-zb-cropper-img/"
# 发送请求并获取页面内容
response = requests.get(WebUrl)
html_content = response.text

# 使用Beautiful Soup解析HTML
soup = BeautifulSoup(html_content, 'html.parser')


# 获取所有图片标签
img_tags = soup.find_all('img')

filePath = 'D:/Python/JiaGuWen/JiaGuWen/SAN'

# 创建目录用于保存图片
os.makedirs('D:/Python/JiaGuWen/JiaGuWen/SAN', exist_ok=True)


# 下载并保存每张图片
for img_tag in img_tags:
    img_src = img_tag['src']

    # 处理图片格式字符串
    img_name = img_src.split('!')[0]  # 获取文件名部分

    img_url = urljoin(WebUrl, img_src)
    img_data = requests.get(img_url).content

    # 获取图片文件名
    img_name = filePath + os.path.join('downloaded_images', img_name)

    # 保存图片
    with open(img_name, 'wb') as f:
        f.write(img_data)



#
#