'''
骨架提取
'''
import cv2
import numpy as np

# 由于我们经过之前的代码转换到了二值图，所以这里不需要转换
img = cv2.imread('D:\Python\JiaGuWen\JiaGuWen\R-C.jpg', cv2.IMREAD_GRAYSCALE)
dst = img.copy()

skeleton = np.zeros(dst.shape, np.uint8)
while (True):
    if np.sum(dst) == 0:
        break
    kernel = cv2.getStructuringElement(cv2.MORPH_CROSS, (7, 7))
    dst = cv2.erode(dst, kernel, None, None, 1)
    open_dst = cv2.morphologyEx(dst, cv2.MORPH_OPEN, kernel)
    result = dst - open_dst
    skeleton = skeleton + result
    cv2.waitKey(1)

cv2.namedWindow("result", 0)
cv2.resizeWindow("result", 640, 480)
cv2.imshow('result', skeleton)
cv2.imwrite("output.png", skeleton)

cv2.waitKey(0)
cv2.destroyAllWindows()