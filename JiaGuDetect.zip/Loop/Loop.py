import cv2
import numpy as np

# 读取图像
img = cv2.imread('D:\Python\JiaGuWen\JiaGuDetect\Preprocessing\skeletonWithKernelM.png')

# # 将图像转换为灰度
# gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
#
# # 进行图像二值化处理
# _, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)

# cv2.imshow('img',binary)
# 执行轮廓检测
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
ret, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
cv2.imshow('Image with Stars', img)
cv2.waitKey(0)
contours, hierarchy = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
# cv2.drawContours(img, contours, -1, (0, 0, 255), 3)
# contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

print(len(contours))

cv2.drawContours(img, contours, -1, (0,0,255), 3)


# 遍历轮廓
for contour in contours:
    # 假设 contour 是你的轮廓

    # 计算轮廓的周长
    perimeter = cv2.arcLength(contour, True)

    # 近似轮廓，其中epsilon是从原始轮廓到近似轮廓的最大距离
    epsilon = 0.5 * perimeter
    approx = cv2.approxPolyDP(contour, epsilon, True)

    # 如果近似的轮廓是闭合的，说明是一个闭环

    # 获取轮廓的边界框
    x, y, w, h = cv2.boundingRect(contour)

    # 绘制边界框
    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # # 绘制轮廓
    # cv2.drawContours(img, [approx], 0, (0, 255, 0), 2)



# 显示结果
cv2.imshow('Detected Closed Loop', img)
cv2.imwrite("output.png", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
