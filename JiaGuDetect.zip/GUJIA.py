import cv2
import numpy as np

# 读取骨架图
skeleton_img = cv2.imread('D:\Python\JiaGuWen\JiaGuDetect\Preprocessing\skeletonWithKernelM.png', cv2.IMREAD_GRAYSCALE)

# # 阈值化
# _, thresholded = cv2.threshold(skeleton_img, 127, 255, cv2.THRESH_BINARY)

# 查找轮廓
contours, _ = cv2.findContours(skeleton_img, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

# 初始化关节点和边缘点列表
keypoints = []
edge_points = []

# 循环处理每个轮廓
for contour in contours:
    # 简化轮廓
    epsilon = 0.02 * cv2.arcLength(contour, True)
    simplified_contour = cv2.approxPolyDP(contour, epsilon, True)

    # 获取关节点
    if len(simplified_contour) == 2:
        edge_points.extend(simplified_contour)
    elif len(simplified_contour) > 2:
        keypoints.extend(simplified_contour)

# 绘制关节点和边缘点
result_img = cv2.cvtColor(skeleton_img, cv2.COLOR_GRAY2BGR)
# 绘制关节点
for point in keypoints:
    cv2.circle(result_img, tuple(point[0]), 5, (0, 255, 0), -1)

# 绘制边缘点
for point in edge_points:
    cv2.circle(result_img, tuple(point[0]), 5, (255, 0, 255), -1)





# 显示结果图像
cv2.imshow("Skeleton Image with Keypoints and Edges", result_img)
cv2.waitKey(0)
cv2.destroyAllWindows()
