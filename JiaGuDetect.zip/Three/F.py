
import cv2
import numpy as np

def extract_features(image):

    # 计算梯度
    gradient_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
    gradient_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)

    # 计算梯度幅值和方向
    magnitude = np.sqrt(gradient_x ** 2 + gradient_y ** 2)
    direction = np.arctan2(gradient_y, gradient_x)

    # 对方向场进行平滑处理
    smoothed_direction = cv2.GaussianBlur(direction, (0, 0), 2)

    # 提取特征，可以根据具体需求选择不同的特征
    features = smoothed_direction.flatten()

    return features